import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HeroPowerstatsComponentComponent } from './hero-powerstats-component.component';

describe('HeroPowerstatsComponentComponent', () => {
  let component: HeroPowerstatsComponentComponent;
  let fixture: ComponentFixture<HeroPowerstatsComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HeroPowerstatsComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HeroPowerstatsComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
