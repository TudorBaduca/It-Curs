import { Component, Input, OnInit } from '@angular/core';

import { Hero } from "../interfaces/Hero";

@Component({
  selector: 'app-hero-powerstats-component',
  templateUrl: './hero-powerstats-component.component.html',
  styleUrls: ['./hero-powerstats-component.component.css']
})
export class HeroPowerstatsComponentComponent implements OnInit {

  @Input() hero?: Hero;

  constructor() { }

  ngOnInit(): void {
  }

}
