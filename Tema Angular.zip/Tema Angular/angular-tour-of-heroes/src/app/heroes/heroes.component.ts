import { Component, OnInit } from '@angular/core';

import { Hero } from '../interfaces/Hero';
import { PowerStats } from '../interfaces/power-stats';

@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.css'],
})
export class HeroesComponent implements OnInit {
  //  hero = 'Windstorm';

  //  hero: Hero = {
  //   id: 1,
  //   name: 'Windstorm'
  // };

  heroes: Hero[] = [
    {id: 11,name: 'Dr Nice',powerStats:new PowerStats(  1,  6, 8,  5,  10 )},
    { id: 12, name: 'Narco',powerStats:new PowerStats(  5,  6, 8,  5, )},
    { id: 13, name: 'Bombasto',powerStats:new PowerStats(  5,  6, 8,  5, )},
    { id: 14, name: 'Celeritas',powerStats:new PowerStats(  5,  6, 8,  5, )},
    { id: 15, name: 'Magneta',powerStats:new PowerStats(  5,  6, 8,  5, )},
    { id: 16, name: 'RubberMan',powerStats:new PowerStats(  5,  6, 8,  5, )},
    { id: 17, name: 'Dynama',powerStats:new PowerStats(  5,  6, 8,  5, )},
    { id: 18, name: 'Dr IQ',powerStats:new PowerStats(  5,  6, 3,  5, )},
    { id: 19, name: 'Magma',powerStats:new PowerStats(  5,  6, 8,  5, )},
    { id: 20, name: 'Tornado',powerStats:new PowerStats(  5,  6, 8,  4, )},
  ];

  selectedHero?: Hero;

  constructor() {}

  ngOnInit(): void {}

  onSelect(hero: Hero): void {
    this.selectedHero = hero;
  }
}
