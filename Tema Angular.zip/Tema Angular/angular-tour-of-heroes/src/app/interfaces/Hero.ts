import { PowerStats } from './power-stats';

export interface Hero {
  id: number;
  name: string;
  powerStats: PowerStats;
}
