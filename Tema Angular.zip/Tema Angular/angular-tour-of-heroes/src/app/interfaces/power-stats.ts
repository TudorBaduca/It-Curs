export class PowerStats {
  combat: number;
  speed: number;
  intelligence: number;
  strength: number;
  fame?: number;
  constructor(
    combat: number,
    speed: number,
    intelligence: number,
    strength: number,
    fame?: number
  ) {
    this.combat = combat;
    this.speed = speed;
    this.intelligence = intelligence;
    this.strength = strength;
    this.fame = fame;
  }

  get overallRating() {
    return (this.speed + this.combat + this.intelligence + this.strength + (this.fame || 0));
  }
}
