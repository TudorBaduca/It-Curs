$.ajax({
  url: "index.json",
  method: "GET",
  success: function (response) {
    var movies = response;
    for (let i = 0; i < movies.length; i++) {
      $("#movies").append(
        `<tr id = "true_remove${i}">
              <td>${movies[i].nr}</td>
              <td> <img src="${movies[i].poster}" alt=""/></td>
              <td>${movies[i].title}</td>
              <td>${movies[i].data}</td>
              <td>${movies[i].actors}</td>
              <td>${movies[i].directors}</td>
              <td>${movies[i].rating}</td>
              <td> <a href="${movies[i].link}" >Movie</a></td>
              <td><button id ="remove_button${i}">Remove</button></td>
          </tr>`
      );

      $(`#remove_button${i}`).click(function(){
          $(`#true_remove${i}`).remove();


      })
    }
  },
});
