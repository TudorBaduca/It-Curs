$(document).ready(function() {
  const app = new Application();
  app.init();
})
