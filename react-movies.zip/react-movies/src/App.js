import logo from './logo.svg';
import './App.css';
import MovieList from './MovieList';

function App() {
  return (
    <div>
      
      <div>
        <MovieList>
        </MovieList>
      </div>
    </div>
  
  );
}

export default App;
