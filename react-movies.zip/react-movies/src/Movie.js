function Movie(params) {
    return (
        
    <tr>
        <td>{params.movie.id}</td>
        <td> <img src={params.movie.picture_url} alt=""/></td>
        <td>{params.movie.title}</td>
        <td>{params.movie.released_date}</td>
        <td> <a href={params.movie.imdb_link} >Movie</a></td>                   
    </tr>
        
     
    );
  }
  
  export default Movie;
  