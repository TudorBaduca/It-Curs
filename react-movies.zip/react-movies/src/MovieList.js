import { useState, useEffect } from "react";
import Movie from "./Movie";
import $ from "jquery";
function MovieList() {
  // var movies = [];
  var [movies, setMovies] = useState([]);

  useEffect(function () {
    //descarcam 1 singura data

    $.ajax({
      url: "http://localhost:4000/movies",
      method: "GET",
      success: function (response) {
        // Ce sa se intample cu ce a descarcat
        setMovies(response);
      },
    });
  }, []);

  // fetch("http://localhost:4000/movies").then(function(resp){
  //   // movies = resp;
  //   setMovies(resp.json());
  // });
  console.log(movies);
  return (
    <div>
      <table id="movies">
        <thead>
          <tr>
            <th>Nr.</th>
            <th>Poster</th>
            <th>Name</th>
            <th>Data</th>
            {/* <th>Actors</th>
          <th>Directors</th>
          <th>Rating</th> */}
            <th>Link IMDB</th>
            {/* <th>Remove</th> */}
          </tr>
        </thead>

        <tbody>
          {/* <Movie movie = {movies[0]}></Movie>
        <Movie movie = {movies[1]}></Movie> */}
          {movies.map(function (m) {
            return <Movie movie={m}></Movie>;
          })}
        </tbody>
      </table>
    </div>
  );
}

export default MovieList;
